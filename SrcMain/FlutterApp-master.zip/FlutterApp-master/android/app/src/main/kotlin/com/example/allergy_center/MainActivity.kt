package com.example.allergy_center

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
