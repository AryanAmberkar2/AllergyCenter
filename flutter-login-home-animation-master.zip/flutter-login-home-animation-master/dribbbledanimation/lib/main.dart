import 'package:dribbbledanimation/Routes.dart';

void main() {
  new Routes();
}
